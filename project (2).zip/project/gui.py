from flask import Flask, render_template, Response, stream_with_context, jsonify, request, render_template_string
from flask_mail import Mail, Message
import requests
import random

app = Flask(__name__)

#---------------------------------------------------------------------------------이메일 설정부--------------------------------------------------------------------------------------
app.config['MAIL_SERVER'] = 'smtp.naver.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True                  # ✅ SSL 사용
app.config['MAIL_USE_TLS'] = False                 # ✅ TLS는 끄기 (SSL과 동시에 쓰면 안됨)
app.config['MAIL_USERNAME'] = 'jangsekin29@naver.com'        # ✔ 본인 이메일
app.config['MAIL_PASSWORD'] = "23!08@9jji!@"           # ✔ 앱 비밀번호 사용
mail = Mail(app)
# 라즈베리파이의 API URL ###############################################################수정필요
RASPBERRY_PI_API_URL = "http://<라즈베리파이_IP>:5001/start-face-recognition"
#-------------------------------------------------------------------------------------라우팅-----------------------------------------------------------------------------------------
# 홈 페이지
@app.route('/')
def home():
    return render_template('index.html')

# Room Select 페이지
@app.route('/room-select')
def room_select():
    return render_template('room-select.html')

# Check-out 페이지
@app.route('/check-out')
def check_out():
    return render_template('CHECK-OUT.html')

# Admin Mode 페이지
@app.route('/admin-mode')
def admin_mode():
    return render_template('ADMIN-MODE.html')

# Home 페이지
@app.route('/home')
def home_page():
    return render_template('Home.html')

# Page-1 페이지
@app.route('/page-1')
def page_1():
    return render_template('Page-1.html')

# Password and Room 페이지
@app.route('/password-and-room')
def password_and_room():
    return render_template('password-and-room.html')

# Payment 페이지
@app.route('/payment')
def payment():
    return render_template('payment.html')

# Verification 페이지
@app.route('/verification')
def verification():
    return render_template('verification.html')

#-----------------------------------------------------------------------MJPEG 스트림 프록시--------------------------------------------------------------------------------
@app.route('/camera-stream')
def camera_stream():
    # 라즈베리파이 MJPEG 스트리머 URL #########################################################수정필요
    mjpeg_url = "http://192.168.0.100:8080/stream"
    
    # MJPEG 스트림 요청
    def generate():
        try:
            with requests.get(mjpeg_url, stream=True, timeout=10) as r:
                r.raise_for_status()  # HTTP 에러 확인
                for chunk in r.iter_content(chunk_size=1024):
                    if chunk:  # 빈 청크 방지
                        yield chunk
        except requests.exceptions.RequestException as e:
            print(f"스트림 요청 실패: {e}")
            yield b"--frame\r\nContent-Type: text/plain\r\n\r\n" + "스트림 연결 실패".encode('utf-8') + b"\r\n\r\n"

    return Response(stream_with_context(generate()), content_type='multipart/x-mixed-replace; boundary=frame')

#------------------------------------------------------------------------얼굴 인식 요청 처리------------------------------------------------------------------------------
@app.route('/start-face-recognition', methods=['POST'])
def start_face_recognition():
    try:
        # 라즈베리파이 API 호출
        response = requests.post(RASPBERRY_PI_API_URL)
        if response.status_code == 200:
            return jsonify(response.json())  # 라즈베리파이의 결과를 클라이언트로 전달
        else:
            return jsonify({"status": "error", "message": "라즈베리파이 요청 실패"}), 500
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    
#---------------------------------------------------------------------------이메일 전송-------------------------------------------------------------------------------------  
@app.route('/send-code', methods=['POST'])
def send_code():
    email = request.form.get('email')
    if not email:
        return "이메일을 입력해주세요.", 400

    code = str(random.randint(1000, 9999))

    try:
        msg = Message('인증 코드', sender=app.config['MAIL_USERNAME'], recipients=[email])
        msg.body = f'요청하신 인증 코드는 {code} 입니다.'
        mail.send(msg)

        return render_template_string(f"""
            <!DOCTYPE html>
            <html><head><meta charset="utf-8"><title>이메일 전송 완료</title></head>
            <body style="font-family: sans-serif; text-align: center; padding: 50px;">
              <h2>인증 코드가 <strong>{email}</strong> 로 전송되었습니다.</h2>
              <a href="/password-and-room">돌아가기</a>
            </body></html>
        """)
    except Exception as e:
        return f"이메일 전송 중 오류 발생: {str(e)}", 500  

#---------------------------------------------------------------------------서버 실행---------------------------------------------------------------------------------------
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)  # ✅ 외부 접속 가능하도록 설정