from flask import Flask, render_template, Response, stream_with_context
import requests

app = Flask(__name__)

# 홈 페이지
@app.route('/')
def home():
    return render_template('index.html')

# Room Select 페이지
@app.route('/room-select')
def room_select():
    return render_template('room-select.html')

# Check-out 페이지
@app.route('/check-out')
def check_out():
    return render_template('CHECK-OUT.html')

# Admin Mode 페이지
@app.route('/admin-mode')
def admin_mode():
    return render_template('ADMIN-MODE.html')

# Home 페이지
@app.route('/home')
def home_page():
    return render_template('Home.html')

# Page-1 페이지
@app.route('/page-1')
def page_1():
    return render_template('Page-1.html')

# Password and Room 페이지
@app.route('/password-and-room')
def password_and_room():
    return render_template('password-and-room.html')

# Payment 페이지
@app.route('/payment')
def payment():
    return render_template('payment.html')

# Verification 페이지
@app.route('/verification')
def verification():
    return render_template('verification.html')

# MJPEG 스트림 프록시
@app.route('/camera-stream')
def camera_stream():
    # 라즈베리파이 MJPEG 스트리머 URL
    mjpeg_url = "http://192.168.0.100:8080/stream"
    
    # MJPEG 스트림 요청
    def generate():
        with requests.get(mjpeg_url, stream=True) as r:
            for chunk in r.iter_content(chunk_size=1024):
                yield chunk

    return Response(stream_with_context(generate()), content_type='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)  # ✅ 외부 접속 가능하도록 설정